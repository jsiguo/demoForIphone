//
//  HomeViewController.h
//  AutoScrollViewDemo
//
//  Created by guoshiming on 12-8-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AutoScrollView.h"
@interface HomeViewController : UIViewController<CycleScrollViewDelegate>{
    
}
- (IBAction)tunClick:(id)sender;

@end
