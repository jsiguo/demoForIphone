//
//  UIImage+SplitImageIntoTwoParts.h
//  TapRepublic
//
//  Created by guoshiming on 12-9-9.
//  Copyright (c) 2012年 guoshiming. All rights reserved.
//

/*对UIImage进行扩充
 *用于将图片撕成2半
 */

#import <UIKit/UIKit.h>

@interface UIImage (SplitImageIntoTwoParts)
+ (NSArray*)splitImageIntoTwoParts:(UIImage*)image;
@end
