//
//  QQstyleTableViewViewController.h
//  QQstyleTableView
//
//  Created by xhan on 9/22/09.
//  Copyright In-Blue 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QQstyleTableViewViewController : UIViewController < UITableViewDelegate , UITableViewDataSource , UIScrollViewDelegate > {
	UITableView* _tableView;
	NSMutableArray* _array;
	BOOL *flag;
}

@property (nonatomic, retain) UITableView *tableView;

- (int)numberOfRowsInSection:(NSInteger)section;

@end


