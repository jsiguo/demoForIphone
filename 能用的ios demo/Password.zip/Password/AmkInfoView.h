//
//  AmkInfoView.h
//  Password
//
//  Created by apple on 8/31/08.
//  Copyright 2008 ACS Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AmkInfoView : UIAlertView {

}
- (id)initWithMessage:(NSString *)message delegate:(id)delegate;
@end
