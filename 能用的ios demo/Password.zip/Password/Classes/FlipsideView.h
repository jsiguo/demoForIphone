//
//  FlipsideView.h
//  PasswordGen
//
//  Created by amuck on 8/18/08.
//  Copyright AppsAmuck LLC 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlipsideView : UIView {
}

- (IBAction)openLink;

@end
