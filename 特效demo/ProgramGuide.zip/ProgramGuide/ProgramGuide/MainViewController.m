//
//  MainViewController.m
//  ProgramGuide
//
//  Created by guoshiming on 12-9-9.
//  Copyright (c) 2012年 guoshiming. All rights reserved.
//

#import "MainViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self.view setBackgroundColor:[UIColor whiteColor]];
    UILabel *lable= [[UILabel alloc]initWithFrame:CGRectMake(100, 40, 100, 30)];
    [lable setBackgroundColor:[UIColor clearColor]];
    [lable setTextColor:[UIColor redColor]];
    [lable setFont:[UIFont systemFontOfSize:14.0f]];
    [lable setText:@"主界面"];
    [self.view addSubview:lable];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
