// *********************************:************************************************************************************************
// iOS 5 API Reference Offline		: http://itunes.apple.com/app/api-reference-for-ios4-3/id440176532?mt=8
// Mac OS Developer Library API		: http://itunes.apple.com/app/developer-library-for-mac-os-x/id445325586?mt=8
// jQuery API Reference on iPhone	: http://itunes.apple.com/app/jquery-api-doc/id439568711?mt=8
// PHPManual & Reference			: http://itunes.apple.com/app/php-manual-php-function-reference/id445298555?mt=8
// Color Tool						: http://itunes.apple.com/app/color-matching/id439572532?mt=8
// *********************************:************************************************************************************************
//
//  Created by pysh on 11-7-7.
//  Copyright 2011年 asparagus. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DoSpringBoardViewController;

@interface DoSpringBoardAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet DoSpringBoardViewController *viewController;

@end
