//
//  TestActionSheetViewController.h
//  TestActionSheet
//
//  Created by Cui Lionel on 10-12-8.
//  Copyright 2010 vlion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestActionSheetViewController : UIViewController {

}
-(IBAction)btndown;
@end

