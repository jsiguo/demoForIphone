//
//  HealthierClockAppDelegate.h
//  FMDBdemo
//
//  Created by 亭 王 on 12-4-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HealthierClockViewController;

@interface HealthierClockAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) HealthierClockViewController *viewController;

@end
