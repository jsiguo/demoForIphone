//
//  main.m
//  DoSpringBoard
//
//  Created by pysh on 11-7-7.
//  Copyright 2011年 asparagus. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, nil);
	[pool release];
	return retVal;
}
