//
//  QQViewTestAppDelegate.h
//  QQViewTest
//
//  Created by  wondertek on 10-5-28.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QQViewController.h"

@interface QQViewTestAppDelegate : NSObject <UIApplicationDelegate> {
	QQViewController *qq;
    UIWindow *window;
}
@property (nonatomic, retain) QQViewController *qq;
@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

