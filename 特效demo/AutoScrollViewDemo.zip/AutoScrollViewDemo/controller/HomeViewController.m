//
//  HomeViewController.m
//  AutoScrollViewDemo
//
//  Created by guoshiming on 12-8-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "HomeViewController.h"

@interface HomeViewController (){
    AutoScrollView *autScrollView;
    UILabel *myLable;
}
@property(nonatomic,retain)AutoScrollView *autScrollView;
@property(nonatomic,retain)UILabel *lable;
@end

@implementation HomeViewController
@synthesize lable;
@synthesize autScrollView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	NSMutableArray *picArray = [[NSMutableArray alloc] init];
   
    //获取图片
    
    //第一种方式
//    [picArray addObject:[UIImage imageNamed:@"01.png"]];
//    [picArray addObject:[UIImage imageNamed:@"02.png"]];
//    [picArray addObject:[UIImage imageNamed:@"03.png"]];
//    [picArray addObject:[UIImage imageNamed:@"04.png"]];
//    [picArray addObject:[UIImage imageNamed:@"05.png"]];
//    [picArray addObject:[UIImage imageNamed:@"06.png"]];
    
    //第二种方式
//    for (int i=1 ; i<=18; i++) {
//        NSString *temp = i < 10 ? [NSString stringWithFormat:@"0%d.png",i] : [NSString stringWithFormat:@"%d.png",i];
//        [picArray addObject:[UIImage imageNamed:temp]];
//    }
    
    //第三种方式  
    NSString *path = [[NSBundle mainBundle]pathForResource:@"content_iPhone" ofType:@"plist"];
    NSArray *imageArray = [NSArray arrayWithContentsOfFile:path];
    NSDictionary *imageItem;
    NSLog(@"=====%d",[imageArray count]);
    for (int i = 0; i < [imageArray count]; i++) {
        imageItem = [imageArray objectAtIndex:i];
        [picArray addObject:[UIImage imageNamed:[imageItem objectForKey:@"imageKey"]]];
        NSString *temp = [imageItem objectForKey:@"nameKey"];
        NSLog(@"===%@",temp);
    }
    
    
    autScrollView = [[AutoScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 140)cycleDirection:CycleDirectionLandscape pictures:picArray];
    autScrollView.delegate = self;
    [self.view addSubview:autScrollView];
    [picArray release];
    
    CGRect frame = CGRectMake(10,250,140,40);
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    loginBtn.frame = frame; 
    [loginBtn setBackgroundColor:[UIColor clearColor]];
    [loginBtn setTitle:@"点我哈哈" forState:UIControlStateNormal];
    [loginBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [loginBtn setTag:100];
    [self.view addSubview:loginBtn];
    
    myLable = [[UILabel alloc]initWithFrame:CGRectMake(10, 300, 300, 40)];
    [myLable setBackgroundColor:[UIColor lightGrayColor]];
    [myLable setText:@"我是动态生成的哈哈"];
    myLable.font = [UIFont fontWithName:@"Verdana" size:14];
    [myLable setTextColor:[UIColor blackColor]];
    [myLable setTextAlignment:UITextAlignmentCenter];
    [self.view addSubview:myLable];
}

-(void)btnClick:(id)sender{
    NSLog(@"tag=%d",[sender tag]);
    myLable.text = [NSString stringWithFormat:@"你点击了tag=%d的button",[sender tag]];
}

#pragma mark - CycleScrollViewDelegate
- (void)cycleScrollViewDelegate:(AutoScrollView *)cycleScrollView didSelectImageView:(int)index {
        
    [[[[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"点击了第%d张", index] 
                                 message:nil 
                                delegate:nil 
                       cancelButtonTitle:@"确定" 
                       otherButtonTitles: nil] autorelease] show];
}

- (void)cycleScrollViewDelegate:(AutoScrollView *)cycleScrollView didScrollImageView:(int)index {
    //    if (index == 4) {
    //        [self.navigationController setNavigationBarHidden:NO animated:YES];
    //    }
    
    //    self.title = [NSString stringWithFormat:@"第%d张", index];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    self.autScrollView = nil;
    self.lable = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)dealloc{
    [super dealloc];
    [self.autScrollView release];
    [self.lable release];
}
- (IBAction)tunClick:(id)sender {
    
}
@end
