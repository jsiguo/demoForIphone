//
//  SecondViewController.h
//  PPRevealSideViewController
//
//  Created by Marian PAUL on 18/02/12.
//  Copyright (c) 2012 Marian PAUL aka ipodishima — iPuP SARL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
- (IBAction)pushToPreviousLeft:(id)sender;

@end
