//
//  HomeViewController.h
//  phoneaddress
//
//  Created by guo shiming on 12-5-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>

@interface HomeViewController : UIViewController
- (IBAction)btnOnClick:(id)sender;

@end
