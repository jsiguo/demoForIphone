//
//  RootNavigationController.m
//  RootViewController.h
//  TQQTableView
//
//  Created by Futao on 11-6-21.
//  Copyright 2011 ftkey.com. All rights reserved.
//

#import "RootNavigationController.h"
#import "QQList.h"
@implementation RootNavigationController



- (void)loadView {
	[super loadView];
}

- (void)viewDidLoad {
    [super viewDidLoad];

}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
	//return (interfaceOrientation == UIInterfaceOrientationPortrait);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (void)viewDidUnload {
    [super viewDidUnload];
}


- (void)dealloc {
    [super dealloc];
}


@end

#define HEADER_HEIGHT 35

@implementation RootViewController

- (void) loadQQData
{	
	NSString * path= [[NSBundle mainBundle] pathForResource:@"Spot" ofType:@"plist"] ;
	//使用静态变量不用理会释放内存问题
	NSDictionary * dic = [[[NSDictionary alloc] initWithContentsOfFile:path] autorelease];
	NSArray* nameArray = [[dic allKeys] retain];
		
	//一级菜单
	for (int i = 0 ; i < [nameArray count]; i++)
	{
		QQList *list = [[[QQList alloc] init] autorelease];
		//list.m_nID = i;
		list.m_strName = [nameArray objectAtIndex:i];
		list.m_arrayPersons = [[[NSMutableArray alloc] init] autorelease];
		list.opened = YES;
		
					
		openItemArray = [dic valueForKey:[nameArray objectAtIndex:i]];
		//判断打开的菜单
		for (int j = 0 ; j < [openItemArray count]; j++)
		{
			QQPerson *person = [[[QQPerson alloc] init] autorelease];
			person.m_nListID = i;
			person.m_strNickName = [openItemArray objectAtIndex:j];
			[list.m_arrayPersons addObject:person];
		}
		[lists addObject:list];
	}
	
}

- (void)loadView {
	[super loadView];
	lists =[[[NSMutableArray alloc] init] retain];
	openItemArray = [[[NSMutableArray alloc] init] retain];
	[self performSelector:@selector(loadQQData)];
	

}

- (void)viewDidLoad {
    [super viewDidLoad];
	[self setTitle:@"QQTableView"];
	self.tableView.delegate = self;
	self.tableView.dataSource = self;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
	//return (interfaceOrientation == UIInterfaceOrientationPortrait);
	
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (void)viewDidUnload {
    [super viewDidUnload];
}


- (void)dealloc {
	[lists release];
	[openItemArray release];
    [super dealloc];
}



#pragma mark -
#pragma mark Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return HEADER_HEIGHT;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [lists count]; // 分组数
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	QQList *persons = [lists objectAtIndex:section];
	if ([persons opened]) {
		return [persons.m_arrayPersons count]; // 人员数

	}else {
		return 0;	// 不展开
	}

}

-(UIView*)tableView:(UITableView*)tableView viewForHeaderInSection:(NSInteger)section {
	QQList *persons = [lists objectAtIndex:section];
	int onlineCount = 0 ;
	for (QQPerson *person in persons.m_arrayPersons) {
		if ([person isOnline]) {
			onlineCount ++; // 统计在线人数,排序 (可以用线程来做,防止UI卡顿)
		}
	}
	NSString *headString = [NSString stringWithFormat:@"%@ [%d/%d] ",persons.m_strName,onlineCount,[persons.m_arrayPersons count]];
	
	QQSectionHeaderView *sectionHeadView = [[QQSectionHeaderView alloc] 
											initWithFrame:CGRectMake(0.0, 0.0, self.tableView.bounds.size.width, HEADER_HEIGHT) 
																				title:headString 
																			   section:section 
																				opened:persons.opened
																			
																			  delegate:self] ;
	return [sectionHeadView autorelease];
}
// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    }
	QQList *persons = [lists objectAtIndex:indexPath.section];
    QQPerson *person = [persons.m_arrayPersons objectAtIndex:indexPath.row];

	cell.textLabel.text = person.m_strNickName;
	[cell textLabel].font = [UIFont boldSystemFontOfSize:14.0];
	
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath 
{ 
    return YES; 
} 
////*
//// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle 
			forRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	NSMutableArray *array = [[NSMutableArray alloc] init];
	NSInteger row = [indexPath row];
    [array addObjectsFromArray:lists];
    [array removeObjectAtIndex:row];
    lists = array;
    [array release];
	// [lists reloadData];
	[tableView reloadData];
	//[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
}

-(void)sectionHeaderView:(QQSectionHeaderView*)sectionHeaderView sectionClosed:(NSInteger)section
{
	QQList *persons = [lists objectAtIndex:section];
	persons.opened = !persons.opened;
	
	
	// 收缩+动画 (如果不需要动画直接reloaddata)
	NSInteger countOfRowsToDelete = [self.tableView numberOfRowsInSection:section];
    if (countOfRowsToDelete > 0) {
        persons.indexPaths = [[NSMutableArray alloc] init];
        for (NSInteger i = 0; i < countOfRowsToDelete; i++) {
            [persons.indexPaths addObject:[NSIndexPath indexPathForRow:i inSection:section]];
        }
        [self.tableView deleteRowsAtIndexPaths:persons.indexPaths withRowAnimation:UITableViewRowAnimationTop];
    }
}

-(void)sectionHeaderView:(QQSectionHeaderView*)sectionHeaderView sectionOpened:(NSInteger)section
{
	QQList *persons = [lists objectAtIndex:section];
	persons.opened = !persons.opened;
	
	// 展开+动画 (如果不需要动画直接reloaddata)
	if(persons.indexPaths){
		[self.tableView insertRowsAtIndexPaths:persons.indexPaths withRowAnimation:UITableViewRowAnimationBottom];
	}
	persons.indexPaths = nil;
}

@end
