//
//  HealthierClockViewController.m
//  FMDBdemo
//
//  Created by 亭 王 on 12-4-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "HealthierClockViewController.h"
#import "FMDatabase.h"

@implementation HealthierClockViewController

FMDatabase *database;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *path = [docsPath stringByAppendingPathComponent:@"database.sqlite"];
    
    database = [FMDatabase databaseWithPath:path];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)createDB:(id)sender {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *path = [docsPath stringByAppendingPathComponent:@"database.sqlite"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL find = [fileManager fileExistsAtPath:path];
    
    if(find){
        NSLog(@"数据库已经存在!");
    }else{
        database = [FMDatabase databaseWithPath:path];
        NSLog(@"数据库成功创建!");
    }
    
}

- (IBAction)createTable:(id)sender {
    [database open];
    [database executeUpdate:@"create table user(name text primary key, age int)"];
    [database close];
    
    NSLog(@"表创建成功!");
}

- (IBAction)queryTable:(id)sender {
    [database open];
    FMResultSet *results = [database executeQuery:@"select * from user"];
    NSLog(@"查询数据库!");
    while([results next]) {
        NSString *name = [results stringForColumn:@"name"];
        NSInteger age  = [results intForColumn:@"age"];        
        NSLog(@"User: %@ - %d",name, age);
    }
    [database close];
    

}

- (IBAction)insertTable:(id)sender {
    NSString *query = [NSString stringWithFormat:@"insert into user values ('%@', %d)",
                       @"brandontreb", 25];
    
//    [database executeUpdate:@"insert into user(name, age) values(?,?)",
//     @"cruffenach",[NSNumber numberWithInt:25],nil];
    [database open];
    [database executeUpdate:query];
    [database close];
    
    NSLog(@"插入数据成功!");
}

- (IBAction)updateTable:(id)sender {
    [database open];
    [database executeUpdate:@"UPDATE User SET Name = ? WHERE Name = ? ",@"老婆",@"brandontreb"];
    [database close];
    
    NSLog(@"记录修改成功!");
}

- (IBAction)deleteTable:(id)sender {
    [database open];
    [database executeUpdate:@"delete from user where age = ?",[NSNumber numberWithInt:25]];
    [database close];
    
    NSLog(@"记录删除成功!");
}
@end
