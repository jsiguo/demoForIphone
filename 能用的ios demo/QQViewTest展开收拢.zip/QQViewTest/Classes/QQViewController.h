//
//  QQViewController.h
//  PhoneMovie
//
//  Created by  wondertek on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface QQViewController : UIViewController {
	NSInteger count;
	NSArray *titleArray;
	
	UIScrollView *scrollView;
	
	NSInteger lasterTag;
	
	BOOL flag;
}
@property (nonatomic, retain) UIScrollView *scrollView;
@property (nonatomic, retain) NSArray *titleArray;

-(IBAction)reSetFrame:(id)sender;
@end
