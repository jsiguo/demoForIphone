//
//  HomeController.m
//  CycleScrollDemo
//
//  Created by guoshiming on 12-8-29.
//  Copyright (c) 2012年 linkcity. All rights reserved.
//

#import "HomeController.h"
#import "CycleScrollView.h"

@interface HomeController (){
    CycleScrollView *cycle;
}
@property(nonatomic,retain)CycleScrollView *cycle;
@end

@implementation HomeController
@synthesize cycle;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"首页";
    

    /*self.navigationItem.title = @"动态创建UI";  
    UIView *myview = [[UIView alloc]initWithFrame:[UIScreen mainScreen].applicationFrame];  
    myview.backgroundColor = [UIColor blackColor];  
    
    CGRect frame = CGRectMake(10, 15, 300, 20);  
    UILabel *mylabel = [[UILabel alloc]initWithFrame:frame];  
    mylabel.text = @"这是动态创建的label";  
    mylabel.backgroundColor = [UIColor clearColor];  
    mylabel.font = [UIFont fontWithName:@"Verdana" size:20];  
    mylabel.textColor = [UIColor lightGrayColor];  
    mylabel.textAlignment = UITextAlignmentCenter;  
    
    frame = CGRectMake(10, 70, 300, 50);  
    //UIButton *mybutton = [[UIButton alloc]initWithFrame:frame];  
    UIButton *mybutton = [UIButton buttonWithType:UIButtonTypeRoundedRect];  
    mybutton.frame = frame;  
    [mybutton setTitle:@"点我" forState:UIControlStateNormal];  
    mybutton.backgroundColor = [UIColor clearColor];  
    [mybutton addTarget:self action:@selector(buttonclc) forControlEvents:UIControlEventTouchUpInside];  
    [myview addSubview:mylabel];  
    [myview addSubview:mybutton];  
    self.view = myview;  
    [mylabel release];  
    [super viewDidLoad]; 
    */
    
   //隐藏导航栏和状态栏
    [UIApplication sharedApplication].statusBarHidden = YES;//导航栏
    [self.navigationController setNavigationBarHidden:YES animated:NO];//状态栏
    
    NSMutableArray *picArray = [[NSMutableArray alloc] init];
    [picArray addObject:[UIImage imageNamed:@"renren_photo1.png"]];
    [picArray addObject:[UIImage imageNamed:@"renren_photo2.png"]];
    [picArray addObject:[UIImage imageNamed:@"renren_photo3.png"]];
    [picArray addObject:[UIImage imageNamed:@"renren_photo4.png"]];
    cycle = [[CycleScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)cycleDirection:CycleDirectionLandscape pictures:picArray];
    cycle.delegate = self;
    [self.view addSubview:cycle];
    [cycle release];
    [picArray release];
}

#pragma mark - CycleScrollViewDelegate
- (void)cycleScrollViewDelegate:(CycleScrollView *)cycleScrollView didSelectImageView:(int)index {
    
    if (index == 4) {
//        [[[[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"点击了第%d张", index] 
//                                     message:nil 
//                                    delegate:nil 
//                           cancelButtonTitle:@"确定" 
//                           otherButtonTitles: nil] autorelease] show];
        //状态栏 导航栏 显示
        [UIApplication sharedApplication].statusBarHidden = NO;//状态栏
        [self.navigationController setNavigationBarHidden:NO animated:NO];//导航栏
        [self.cycle removeFromSuperview];
    }
}

- (void)cycleScrollViewDelegate:(CycleScrollView *)cycleScrollView didScrollImageView:(int)index {
    //    if (index == 4) {
    //        [self.navigationController setNavigationBarHidden:NO animated:YES];
    //    }
    
    //    self.title = [NSString stringWithFormat:@"第%d张", index];
}
    
- (void)viewDidUnload
{
    [super viewDidUnload];
    self.cycle = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)dealloc{
    [super dealloc];
    [self.cycle release];
}
- (IBAction)toPopView {

}
@end
