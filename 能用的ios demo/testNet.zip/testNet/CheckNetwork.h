//
//  CheckNetwork.h
//  testNet
//
//  Created by b126 on 12-4-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CheckNetwork : NSObject {
	
}
+(BOOL)isExistenceNetwork;
@end
