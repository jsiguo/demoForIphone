//
//  RootViewController.h
//  QQ_TableView
//
//  Created by king on 10-9-9.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
	NSMutableArray * itemArray ;
	
	NSMutableArray * openItemArray ;
}

@property (nonatomic , retain) NSMutableArray * itemArray ;

@property (nonatomic , retain) NSMutableArray * openItemArray ;

@end
