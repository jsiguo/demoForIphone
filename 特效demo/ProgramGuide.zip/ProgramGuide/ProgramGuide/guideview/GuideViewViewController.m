//
//  GuideViewViewController.m
//  ProgramGuide
//
//  Created by guoshiming on 12-9-9.
//  Copyright (c) 2012年 guoshiming. All rights reserved.
//

#import "GuideViewViewController.h"
#import "UIImage+SplitImageIntoTwoParts.h"
#import "MainViewController.h"

@interface GuideViewViewController (){
    
}
@property(nonatomic,strong) UIButton *gotoMainViewButton;
@property(nonatomic,strong) UIImageView *lastPagImage;
@property(nonatomic,strong) UIScrollView *pageScroll;
@property(nonatomic,strong) UIPageControl *pageControl;
@property(nonatomic,strong) UIImageView *leftImageView;
@property(nonatomic,strong) UIImageView *rightImageView;
@end

@implementation GuideViewViewController
@synthesize gotoMainViewButton = _gotoMainViewButton;
@synthesize lastPagImage = _lastPageImage;
@synthesize pageScroll = _pageScroll;
@synthesize pageControl = _pageControl;
@synthesize leftImageView = _leftImageView;
@synthesize rightImageView = _rightImageView;

static int pageCount = 0;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    [self setGotoMainViewButton:nil];
    [self setLastPagImage:nil];
    [self setPageScroll:nil];
    [self setPageControl:nil];
    [self setLeftImageView:nil];
    [self setRightImageView:nil];
}

-(void)dealloc{
    [super dealloc];
    [_gotoMainViewButton release];
    [_lastPageImage release];
    [_pageScroll release];
    [_pageControl release];
    [_leftImageView release];
    [_rightImageView release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _pageScroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 320, 460)];
    [_pageScroll setBackgroundColor:[UIColor lightGrayColor]];
    [_pageScroll setPagingEnabled:YES];//翻页效果
    [_pageScroll setShowsHorizontalScrollIndicator:NO];
    [_pageScroll setShowsVerticalScrollIndicator:NO];
    [_pageScroll setDelegate:self];
//    [_pageScroll setBounces:NO];//控制控件遇到边框是否反弹
   
    //初始化滑动界面
    NSArray *images = [NSArray arrayWithObjects:@"0.png",@"1.png",@"2.png",@"3.png",@"renren_photo4.png",@"test6.png", nil];
    pageCount = [images count];
    UIImageView *imageView = nil;
    for (int i = 0; i < pageCount-1; i++) {//pageCount-1是因为最后一个界面要点击消失
        imageView = [[UIImageView alloc]initWithFrame:CGRectMake(320 * i, 0, 320, 460)];
        [imageView setImage:[UIImage imageNamed:[images objectAtIndex:i]]];
        [_pageScroll addSubview:imageView];
        [imageView release];
    }
    
    //点点
    _pageControl = [[UIPageControl alloc]init];
    _pageControl.frame = CGRectMake(10, 400, 300, 40);
    [_pageControl setNumberOfPages:pageCount];//先设置点点数量再设置默认显示位置
    [_pageControl setCurrentPage:0];
    [_pageControl setBackgroundColor:[UIColor redColor]];
    
    //最后一个界面
    UIView *lastView = [[UIView alloc]initWithFrame:CGRectMake(320 *(pageCount - 1), 0, 320, 460)];
    [lastView setBackgroundColor:[UIColor lightGrayColor]];
    _lastPageImage= [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 460)];
    [_lastPageImage setImage:[UIImage imageNamed:[images objectAtIndex:pageCount-1]]];
    [lastView addSubview:_lastPageImage];
    
    _gotoMainViewButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _gotoMainViewButton.frame = CGRectMake(80, 300, 200, 40);
    [_gotoMainViewButton setTitle:@"点击进入主页面" forState:UIControlStateNormal];
    [_gotoMainViewButton addTarget:self action:@selector(gotoMainview:) forControlEvents:UIControlEventTouchUpInside];
    [lastView addSubview:_gotoMainViewButton];
    
    [_pageScroll addSubview:lastView];
    [lastView release];
    
    [_pageScroll setContentSize:CGSizeMake(320*pageCount, 460)];
    [self.view addSubview:_pageScroll];
    [self.view addSubview:_pageControl];
}
-(void)gotoMainview:(id)sender{
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"firstLaunched"];
    [self.gotoMainViewButton setHidden:YES];//隐藏button
    NSArray *array = [UIImage splitImageIntoTwoParts:self.lastPagImage.image];//把最后一张图片分成2半
    self.leftImageView = [[UIImageView alloc]initWithImage:[array objectAtIndex:0]];
    self.rightImageView = [[UIImageView alloc]initWithImage:[array objectAtIndex:1]];
    [self.view addSubview:self.leftImageView];
    [self.view addSubview:self.rightImageView];
    [self.pageScroll setHidden:YES];
    [self.pageControl setHidden:YES];
    
    self.leftImageView.transform = CGAffineTransformIdentity;
    self.rightImageView.transform = CGAffineTransformIdentity;
    //执行动画
    [UIView beginAnimations:@"split" context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    self.leftImageView.transform = CGAffineTransformMakeTranslation(-160 ,0);
    self.rightImageView.transform = CGAffineTransformMakeTranslation(160 ,0);
    [UIView commitAnimations];
}
//执行动画结束方法
-(void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context
{
    if ([animationID isEqualToString:@"split"] && finished) {
        [self.leftImageView removeFromSuperview];
        [self.rightImageView removeFromSuperview];
        NSLog(@"跳到主页面");
        MainViewController *mainView = [[MainViewController alloc]init];
        [self presentModalViewController:mainView animated:YES];
        [mainView release];
    }
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma UIScrollViewDelegate 
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat pageWidth = self.view.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    [_pageControl setCurrentPage:page];
    NSLog(@"当前页面page=%d",page);
}
@end
