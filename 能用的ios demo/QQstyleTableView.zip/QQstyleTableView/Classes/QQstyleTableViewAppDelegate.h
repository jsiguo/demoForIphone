//
//  QQstyleTableViewAppDelegate.h
//  QQstyleTableView
//
//  Created by xhan on 9/22/09.
//  Copyright In-Blue 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class QQstyleTableViewViewController;

@interface QQstyleTableViewAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    QQstyleTableViewViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet QQstyleTableViewViewController *viewController;

@end

