// **********************************************************************************************************************************
// iOS 5 API Reference Offline		: http://itunes.apple.com/app/api-reference-for-ios4-3/id440176532?mt=8
// Mac OS Developer Library API		: http://itunes.apple.com/app/developer-library-for-mac-os-x/id445325586?mt=8
// jQuery API Reference on iPhone	: http://itunes.apple.com/app/jquery-api-doc/id439568711?mt=8
// PHPManual & Reference			: http://itunes.apple.com/app/php-manual-php-function-reference/id445298555?mt=8
// Color Tool						: http://itunes.apple.com/app/color-matching/id439572532?mt=8
// **********************************************************************************************************************************
//
//  Created by pysh on 11-6-30.
//  Copyright 2011年 asparagus. All rights reserved.
//

#import "FileIconView.h"

@implementation FileIconView

@synthesize name,icon,selected;



-(void)singleTap:(UITapGestureRecognizer *)sender{
	self.selected = !self.selected;
	[self setNeedsDisplay];
}

- (id)initWithFrame:(CGRect)frame name:(NSString *)name fileIcon:(UIImage *)icon{
    self = [super initWithFrame:frame];
    if (self) {
		self.name=name;
		self.icon=icon;
		self.selected=NO;
		self.backgroundColor=[UIColor clearColor];
		UITapGestureRecognizer *singleTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTap:) ];
		singleTapGesture.delegate=self;
		[self addGestureRecognizer:singleTapGesture];
		[singleTapGesture release];
		
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect{
	CGContextRef context = UIGraphicsGetCurrentContext();
	int margin = (rect.size.width-57)/2;
	CGRect iconRect = CGRectMake(margin, margin, 57, 57);
	CGRect textRect = CGRectMake(0, rect.size.height-16, rect.size.width, 16);
	if (self.selected) {
		[self.icon drawInRect:iconRect blendMode:kCGBlendModeHardLight alpha:0.3];
	}else{
		[self.icon drawInRect:iconRect];
	}
	[self.name drawInRect:textRect withFont:[UIFont systemFontOfSize:12] lineBreakMode:UILineBreakModeMiddleTruncation alignment:UITextAlignmentCenter];
	
}


- (void)dealloc{
    [super dealloc];
}

@end
