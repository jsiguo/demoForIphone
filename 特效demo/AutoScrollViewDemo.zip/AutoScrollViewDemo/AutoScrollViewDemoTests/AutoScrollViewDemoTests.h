//
//  AutoScrollViewDemoTests.h
//  AutoScrollViewDemoTests
//
//  Created by guoshiming on 12-8-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface AutoScrollViewDemoTests : SenTestCase

@end
