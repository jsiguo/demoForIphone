//
//  HomeViewController.m
//  phoneaddress
//
//  Created by guo shiming on 12-5-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "HomeViewController.h"

@implementation HomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)btnOnClick:(id)sender {
    NSLog(@"获取通讯录");
    
    NSMutableArray *phoneAddressArray = [[NSMutableArray alloc]init]; 
    
    
    ABAddressBookRef addressBook = ABAddressBookCreate();
    CFArrayRef results = ABAddressBookCopyArrayOfAllPeople(addressBook);
    for (int i = 0;i < CFArrayGetCount(results);i++) {
        NSMutableString *phoneInfo = [[NSMutableString alloc] init];//存放电话信息
        
        ABRecordRef person = CFArrayGetValueAtIndex(results, i);
        //读取firstname
        NSString *firstName = (__bridge NSString*)ABRecordCopyValue(person, kABPersonFirstNameProperty);
        if (firstName != nil){
//            NSLog(@"personName= *person%@",firstName);
            [phoneInfo appendString:firstName];
        }
        //读middlename
        NSString *middlename = (__bridge NSString*)ABRecordCopyValue(person, kABPersonMiddleNameProperty);
        if (middlename != nil) {
            //             NSLog(@"middlename=%@",middlename);
            [phoneInfo appendString:middlename];
        }
       //读取lastname
        NSString *lastname = (__bridge NSString*)ABRecordCopyValue(person, kABPersonLastNameProperty);
        if (lastname != nil ) {
//            NSLog(@"personName=%@",lastname);
            [phoneInfo appendString:lastname];
        }
        NSLog(@"name=%@",phoneInfo);
       
        
        
//        //读取电话多值
//        ABMultiValueRef phone = ABRecordCopyValue(person, kABPersonPhoneProperty);
//        for (int k = 0; k<ABMultiValueGetCount(phone); k++)
//        {
//            //获取电话Label
//            NSString * personPhoneLabel = (__bridge NSString*)ABAddressBookCopyLocalizedLabel(ABMultiValueCopyLabelAtIndex(phone, k));
//            //获取該Label下的电话值
//            NSString * personPhone = (__bridge NSString*)ABMultiValueCopyValueAtIndex(phone, k);
//            
////            NSLog(@"personPhoneLabel=%@",personPhoneLabel);
////            NSLog(@"personPhone=%@",personPhone);
//            [phoneInfo appendString:[NSString stringWithFormat:@":%@",personPhone]];
//            NSLog(@"phoneInfo=%@",phoneInfo);
//        }
        
        //获取該Label下的电话值
        ABMultiValueRef phone = ABRecordCopyValue(person, kABPersonPhoneProperty);
        NSString * personPhone = (__bridge NSString*)ABMultiValueCopyValueAtIndex(phone, 0);
        [phoneInfo appendString:[NSString stringWithFormat:@":%@",personPhone]];
        NSLog(@"phoneInfo=%@",phoneInfo);
        
    }    
}
@end
