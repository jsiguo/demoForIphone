//
//  QQViewTestAppDelegate.m
//  QQViewTest
//
//  Created by  wondertek on 10-5-28.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "QQViewTestAppDelegate.h"
#import "QQViewController.h"


@implementation QQViewTestAppDelegate

@synthesize window,qq ;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    

    // Override point for customization after application launch
	qq = [[QQViewController alloc] init];
	NSArray * a = [NSArray arrayWithObjects:@"a",@"aaaaaaaa",nil];
	NSArray * b = [NSArray arrayWithObjects:@"b",@"bbbbbbbb",nil];
	NSArray * c = [NSArray arrayWithObjects:@"c",@"cccccccc",nil];
	NSArray * d = [NSArray arrayWithObjects:@"d",@"dddddddd",nil];
	NSArray * e = [NSArray arrayWithObjects:@"e",@"eeeeeeee",nil];
	NSArray * f = [NSArray arrayWithObjects:@"f",@"ffffffff",nil];
	NSArray * g = [NSArray arrayWithObjects:@"g",@"gggggggg",nil];
	NSArray * h = [NSArray arrayWithObjects:@"h",@"hhhhhhhh",nil];
	NSArray * i = [NSArray arrayWithObjects:@"i",@"iiiiiiii",nil];
	NSArray * j = [NSArray arrayWithObjects:@"j",@"jjjjjjjj",nil];
	
	NSArray *aa = [NSArray arrayWithObjects:a,b,c,d,e,f,g,h,i,j,nil];
	qq.titleArray = aa;
	
	[window addSubview:qq.view];
    [window makeKeyAndVisible];
	
	return YES;
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
