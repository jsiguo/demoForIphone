//
//  ChyoAppDelegate.h
//  PullToRefresh
//
//  Created by hsit on 12-1-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ChyoViewController;

@interface ChyoAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ChyoViewController *viewController;

@end
