//
//  HealthierClockViewController.h
//  FMDBdemo
//
//  Created by 亭 王 on 12-4-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HealthierClockViewController : UIViewController
- (IBAction)createDB:(id)sender;
- (IBAction)createTable:(id)sender;
- (IBAction)queryTable:(id)sender;
- (IBAction)insertTable:(id)sender;
- (IBAction)updateTable:(id)sender;
- (IBAction)deleteTable:(id)sender;

@end
