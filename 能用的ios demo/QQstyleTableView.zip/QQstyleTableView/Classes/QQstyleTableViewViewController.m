//
//  QQstyleTableViewViewController.m
//  QQstyleTableView
//
//  Created by xhan on 9/22/09.
//  Copyright In-Blue 2009. All rights reserved.
//

#import "QQstyleTableViewViewController.h"

@implementation QQstyleTableViewViewController

@synthesize tableView = _tableView;

////////////////////////////////////////////////////////////////////////////////////////
// NSObject 
- (void)dealloc {
	free(flag);
    [_tableView release], _tableView = nil;
    [super dealloc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
	_tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds  style:UITableViewStylePlain];
	_tableView.delegate = self;
	_tableView.dataSource = self;

	[self.view addSubview:_tableView];
	_array = [[NSMutableArray alloc] initWithObjects:[[NSArray alloc] initWithObjects:@"AA",@"BB",@"CC",@"DD",nil],
													 [[NSArray alloc] initWithObjects:@"EE",@"FF",@"GG",@"XX",@"ZZ",nil],	
													 [[NSArray alloc] initWithObjects:@"JJ",@"VV",@"EE",@"NN",nil],
													 nil];
	flag = (BOOL*)malloc([_array count]*sizeof(BOOL*));
	memset(flag, NO, sizeof(flag));

}

////////////////////////////////////////////////////////////////////////////////////////
// 
#pragma mark Table view  delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [_array count];
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [self numberOfRowsInSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"CellIdentifier";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
	NSString* str = [[_array objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
	cell.textLabel.text = str;
	return cell;
}



- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	UIButton *abtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//	abtn.frame = CGRectMake(0, 0, 200, 48);
//	abtn.titleLabel.text = @"HEADER";
	abtn.tag = section;
	[abtn addTarget:self action:@selector(headerClicked:) forControlEvents:UIControlEventTouchUpInside];
	return abtn;
}

////////////////////////////////////////////////////////////////////////////////////////
// 
-(void)headerClicked:(id)sender
{
	int sectionIndex = ((UIButton*)sender).tag;
	flag[sectionIndex] = !flag[sectionIndex];
	[_tableView reloadData];
}

- (int)numberOfRowsInSection:(NSInteger)section
{
	if (flag[section]) {
		return [(NSArray*)[_array objectAtIndex:section] count];
	}
	else {
		return 0;
	}
}

@end

