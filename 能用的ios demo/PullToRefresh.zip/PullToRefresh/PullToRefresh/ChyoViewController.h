//
//  ChyoViewController.h
//  PullToRefresh
//
//  Created by hsit on 12-1-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PullToRefreshTableView.h"

@interface ChyoViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>{
    PullToRefreshTableView * tableView;  
    NSMutableArray         * array;      //  数据源
}

@property (nonatomic, retain) PullToRefreshTableView * tableView;
@property (nonatomic, retain) NSMutableArray                  * array;

- (void)updateThread:(NSString *)returnKey;
- (void)updateTableView;

@end
