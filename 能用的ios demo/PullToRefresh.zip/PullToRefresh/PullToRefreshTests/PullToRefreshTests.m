//
//  PullToRefreshTests.m
//  PullToRefreshTests
//
//  Created by hsit on 12-1-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "PullToRefreshTests.h"

@implementation PullToRefreshTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in PullToRefreshTests");
}

@end
