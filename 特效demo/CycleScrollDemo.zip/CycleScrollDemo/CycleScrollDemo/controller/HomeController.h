//
//  HomeController.h
//  CycleScrollDemo
//
//  Created by guoshiming on 12-8-29.
//  Copyright (c) 2012年 linkcity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeController : UIViewController
- (IBAction)toPopView;

@end
