//
//  QQ_TableViewAppDelegate.m
//  QQ_TableView
//
//  Created by king on 10-9-9.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "QQ_TableViewAppDelegate.h"
#import "RootViewController.h"


@implementation QQ_TableViewAppDelegate

@synthesize window;
@synthesize navigationController;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    // Override point for customization after app launch    
	
	[window addSubview:[navigationController view]];
    [window makeKeyAndVisible];
	return YES;
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Save data if appropriate
}


#pragma mark -
#pragma mark Memory management

- (void)dealloc {
	[navigationController release];
	[window release];
	[super dealloc];
}


@end

