//
//  ProgramGuideTests.m
//  ProgramGuideTests
//
//  Created by guoshiming on 12-9-9.
//  Copyright (c) 2012年 guoshiming. All rights reserved.
//

#import "ProgramGuideTests.h"

@implementation ProgramGuideTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ProgramGuideTests");
}

@end
