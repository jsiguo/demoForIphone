    //
//  QQViewController.m
//  PhoneMovie
//
//  Created by  wondertek on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "QQViewController.h"


@implementation QQViewController
@synthesize titleArray,scrollView;



//titlearray中放置一个array，该array中放title和内容
//整个view的tag为              1   2   10
//button所在的view的tag		 11  21   101
//view中最上面的button的tag为   12  22   102
//前面的image的tag的tag为       13   23  103
//显示标题的label的tag为        14  24   104
//显示的内容的tag为             15  25   105
-(void)viewDidLoad
{
	[super viewDidLoad];
	
	[self.view setBackgroundColor:[UIColor blackColor]];
	
	flag = YES;
	
	scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 460)];
	scrollView.backgroundColor = [UIColor clearColor];
	[self.view addSubview:scrollView];
	
	count = [titleArray count];
	NSInteger totalHeight = 0;//初始化的总高度
	for(int i = 0; i< count; i++)
	{
		NSArray *array = [titleArray objectAtIndex:i];
		
		NSString *QQTitle = [array objectAtIndex:0];//得到标题
		
		NSString *QQContent = [array objectAtIndex:1];//得到内容
		
		UIView *QQView = [[UIView alloc] initWithFrame:CGRectMake(0, totalHeight, 320, 50)];//添加view，开始view的高度为默认的50
		[QQView setBackgroundColor:[UIColor blackColor]];
		[QQView setTag:[[NSString stringWithFormat:@"%d",(i+1)] intValue]];
		[self.scrollView addSubview:QQView];
		
		totalHeight = totalHeight + 1 + 50;
		
		UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];//添加button所在的view，因为该view的颜色要改变，故增加一个view
		[titleView setBackgroundColor:[UIColor grayColor]];
		[titleView setTag:[[NSString stringWithFormat:@"%d1",i+1] intValue]];
		[QQView addSubview:titleView];
		
		UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn setTag:[[NSString stringWithFormat:@"%d2",i+1] intValue]];
		[btn setFrame:CGRectMake(0, 0, 320, 50)];
		[btn addTarget:self action:@selector(reSetFrame:) forControlEvents:UIControlEventTouchUpInside];
		[titleView addSubview:btn];
		
		UIImageView *img = [[UIImageView alloc] initWithFrame:CGRectMake(5, 12, 30, 30)];
		img.image = [UIImage imageNamed:@"list_ico.png"];
		[img setTag:[[NSString stringWithFormat:@"%d3",i+1] intValue]];
		[titleView addSubview:img];
		
		
		UILabel *labTitle = [[UILabel alloc] initWithFrame:CGRectMake(35, 15, 100, 25)];
		labTitle.textColor = [UIColor blackColor];
		labTitle.backgroundColor = [UIColor clearColor];
		labTitle.text = QQTitle;
		[titleView addSubview:labTitle];
		
		UITextView *content = [[UITextView alloc] initWithFrame:CGRectMake(10, 60, 300, 0)];
		content.textColor = [UIColor yellowColor];
		content.backgroundColor = [UIColor clearColor];
		content.text = QQContent;
		content.tag = [[NSString stringWithFormat:@"%d4",i+1] intValue];
		[QQView addSubview:content];
		
		
		[content release];
		[labTitle release];
		[img release];
		[titleView release];
		[QQView release];
	}
	scrollView.contentSize = CGSizeMake(320, totalHeight);
}


-(IBAction)reSetFrame:(id)sender
{
	UIButton *btn = (UIButton *)sender;
	NSInteger btnTag = btn.tag;
	NSLog(@"%d",btnTag);
	
	NSInteger totalHeight = 0;//初始化的总高度
	
	if(lasterTag != btnTag && !flag)
	{
		flag = !flag;
	}
	
	lasterTag = btnTag;
	
	[UIView beginAnimations:nil context:self.view];//开始动画
	[UIView setAnimationDuration:0.3];//设定速度
	for (int i = 0; i < count; i++)
	{
		if(btnTag > [[NSString stringWithFormat:@"%d2",i+1] intValue])//在点击该行前面的行，位置为默认的
		{	
			UIView *titleView = (UIView *)[self.view viewWithTag:[[NSString stringWithFormat:@"%d1",i+1] intValue]];
			titleView.backgroundColor = [UIColor grayColor];
			
			UIView *QQView = (UIView *)[self.view viewWithTag:[[NSString stringWithFormat:@"%d",i+1] intValue]];
			QQView.frame = CGRectMake(0, totalHeight, 320, 50);
			totalHeight = totalHeight + 1 + 50;

			
			UITextView *content = (UITextView*)[self.view viewWithTag:[[NSString stringWithFormat:@"%d4",i+1] intValue]];
			content.frame = CGRectMake(10, 60, 300, 0);
			
			UIImageView *img = (UIImageView*)[self.view viewWithTag:[[NSString stringWithFormat:@"%d3",i+1] intValue]];
			img.image = [UIImage imageNamed:@"list_ico.png"];
			//flag = YES;
		}
		else if(btnTag == [[NSString stringWithFormat:@"%d2",i+1] intValue])//触发当前行
		{
			if(flag)
			{
				UIView *titleView = (UIView *)[self.view viewWithTag:[[NSString stringWithFormat:@"%d1",i+1] intValue]];
				titleView.backgroundColor = [UIColor colorWithRed:0.92 green:0.92 blue:0.92 alpha:0.9];
				
				UIView *QQView = (UIView *)[self.view viewWithTag:[[NSString stringWithFormat:@"%d",i+1] intValue]];
				QQView.frame = CGRectMake(0, totalHeight, 320, 50);
				totalHeight = totalHeight + 1 + 250;

				
				UITextView *content = (UITextView*)[self.view viewWithTag:[[NSString stringWithFormat:@"%d4",i+1] intValue]];
				content.frame = CGRectMake(10, 60, 300, 180);
				
				UIImageView *img = (UIImageView*)[self.view viewWithTag:[[NSString stringWithFormat:@"%d3",i+1] intValue]];
				img.image = [UIImage imageNamed:@"list_ico_d.png"];
				
				flag = !flag;
			}
			else 
			{
				UIView *titleView = (UIView *)[self.view viewWithTag:[[NSString stringWithFormat:@"%d1",i+1] intValue]];
				titleView.backgroundColor = [UIColor grayColor];
				
				UIView *QQView = (UIView *)[self.view viewWithTag:[[NSString stringWithFormat:@"%d",i+1] intValue]];
				QQView.frame = CGRectMake(0, totalHeight, 320, 50);
				totalHeight = totalHeight + 1 + 50;

				
				UITextView *content = (UITextView*)[self.view viewWithTag:[[NSString stringWithFormat:@"%d4",i+1] intValue]];
				content.frame = CGRectMake(10, 60, 300, 0);
				
				UIImageView *img = (UIImageView*)[self.view viewWithTag:[[NSString stringWithFormat:@"%d3",i+1] intValue]];
				img.image = [UIImage imageNamed:@"list_ico.png"];
				
				flag = !flag;
			}
		}
		else//触发行下面的行
		{
			UIView *titleView = (UIView *)[self.view viewWithTag:[[NSString stringWithFormat:@"%d1",i+1] intValue]];
			titleView.backgroundColor = [UIColor grayColor];
			
			UIView *QQView = (UIView *)[self.view viewWithTag:[[NSString stringWithFormat:@"%d",i+1] intValue]];
			QQView.frame = CGRectMake(0, totalHeight, 320, 50);
			totalHeight = totalHeight + 1 + 50;

			
			UITextView *content = (UITextView*)[self.view viewWithTag:[[NSString stringWithFormat:@"%d4",i+1] intValue]];
			content.frame = CGRectMake(10, 60, 300, 0);
			
			UIImageView *img = (UIImageView*)[self.view viewWithTag:[[NSString stringWithFormat:@"%d3",i+1] intValue]];
			img.image = [UIImage imageNamed:@"list_ico.png"];
			//flag = YES;
		}

	}
	scrollView.contentSize = CGSizeMake(320, totalHeight);
	[UIView commitAnimations];
}




/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[scrollView release];
	[titleArray release];
    [super dealloc];
}


@end
