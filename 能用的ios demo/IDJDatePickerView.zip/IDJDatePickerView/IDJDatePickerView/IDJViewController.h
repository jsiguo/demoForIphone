//
//  IDJViewController.h
//  IDJDatePickerView
//
//  Created by lihaifeng on 11-12-1.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IDJDatePickerView.h"

@interface IDJViewController : UIViewController <IDJDatePickerViewDelegate>

@end
