//
//  ThirdViewController.h
//  PPRevealSideViewController
//
//  Created by Marian PAUL on 18/02/12.
//  Copyright (c) 2012 Marian PAUL aka ipodishima — iPuP SARL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController
- (IBAction)pushNavController:(id)sender;
- (IBAction)popPreviousLeft:(id)sender;
- (IBAction)pushNewRight:(id)sender;

@end
