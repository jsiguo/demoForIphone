// **********************************************************************************************************************************
// iOS 5 API Reference Offline		: http://itunes.apple.com/app/api-reference-for-ios4-3/id440176532?mt=8
// Mac OS Developer Library API		: http://itunes.apple.com/app/developer-library-for-mac-os-x/id445325586?mt=8
// jQuery API Reference on iPhone	: http://itunes.apple.com/app/jquery-api-doc/id439568711?mt=8
// PHPManual & Reference			: http://itunes.apple.com/app/php-manual-php-function-reference/id445298555?mt=8
// Color Tool						: http://itunes.apple.com/app/color-matching/id439572532?mt=8
// **********************************************************************************************************************************
//
//  Created by pysh on 11-7-7.
//  Copyright 2011年 asparagus. All rights reserved.
//

#import "DoSpringBoardViewController.h"

@implementation DoSpringBoardViewController
@synthesize desk,files, pageControl,deskWidth,deskHeight;
- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

#pragma mark - View lifecycle
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
	
	self.files = [NSMutableArray arrayWithCapacity:99];
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSArray *allfiles = [fileManager contentsOfDirectoryAtPath:[ [NSBundle bundleForClass:[DoSpringBoardViewController  class]] bundlePath  ] error:nil];		
	
	for (int i=0; i<[allfiles count]; i++) {
		NSString *s = [allfiles objectAtIndex:i];
		if ( [s hasSuffix:@".png"] ) {
			[self.files addObject:s];
		}
	}
	
	
	UIImage *imageSource = [UIImage imageNamed:@"icons"];
	
	deskWidth = self.desk.frame.size.width;
	deskHeight = self.desk.frame.size.height;
	
	for (UIView *subView in desk.subviews) {
		[subView removeFromSuperview];
	}
	
	desk.contentSize = CGSizeMake(self.deskWidth*3, self.deskHeight);
	
	CGFloat iconViewSizeHeight = 86; CGFloat iconViewSizeWidth = 80;
	int col = 0; int row = 0; int page = 0;
	CGRect lastRect;
	for (int i =0; i<[self.files count]; i++) {
		NSString *fname = [self.files objectAtIndex:i];
		fname = [[fname lastPathComponent] stringByDeletingPathExtension];
		CGRect rect = CGRectMake(page*deskWidth+col*iconViewSizeWidth, row*iconViewSizeHeight, iconViewSizeWidth, iconViewSizeHeight);
		lastRect = rect;
		if (rect.origin.x>=(page+1)*deskWidth && rect.origin.y<deskHeight) {
			row = row+1;col = 0;
			rect = CGRectMake(page*deskWidth+col*iconViewSizeWidth, row*iconViewSizeHeight, iconViewSizeWidth, iconViewSizeHeight);
		}
		if (rect.origin.y>=deskHeight) {
			row = 0; col = 0; page=page+1;
			rect = CGRectMake(page*deskWidth+col*iconViewSizeWidth, row*iconViewSizeHeight, iconViewSizeWidth, iconViewSizeHeight);
			//NSLog(@"88 %@ %@",NSStringFromCGRect(rect),fname);
		}		 
		col = col+1;
		FileIconView *icon = [[FileIconView alloc]initWithFrame:rect name:fname fileIcon:[UIImage imageNamed:fname]];
		[self.desk addSubview:icon];
		[icon release];
	}
	
	int totalPage = lastRect.origin.x/deskWidth + 1;
	desk.contentSize = CGSizeMake(self.deskWidth*totalPage, self.deskHeight);
	
	self.pageControl.numberOfPages=totalPage;
	self.pageControl.currentPage=0;
	
}


- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
	self.pageControl.currentPage =  self.desk.contentOffset.x /self.deskWidth ;
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
