//
//  MainAppDelegate.h
//  ProgramGuide
//
//  Created by guoshiming on 12-9-9.
//  Copyright (c) 2012年 guoshiming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
