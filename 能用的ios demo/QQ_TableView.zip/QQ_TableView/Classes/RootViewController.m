//
//  RootViewController.m
//  QQ_TableView
//
//  Created by king on 10-9-9.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "RootViewController.h"


@implementation RootViewController

@synthesize itemArray ;
@synthesize openItemArray ;

#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];

	self.itemArray = [[NSMutableArray alloc] init] ;
	self.openItemArray = [[NSMutableArray alloc] init] ;
	
	[self readPlistToArray] ;
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)readPlistToArray
{
	if ([self.itemArray count]) {
		[self.itemArray removeAllObjects] ;
	}
	
	NSString * path= [[NSBundle mainBundle] pathForResource:@"Spot" ofType:@"plist"] ;
	//使用静态变量不用理会释放内存问题
	NSDictionary * dic = [[[NSDictionary alloc] initWithContentsOfFile:path] autorelease];
	NSArray * nameArray = [dic allKeys] ;

	//一级菜单
	for (int i = 0 ; i < [nameArray count]; i++) {
		NSMutableDictionary * menuDic_1 = [NSMutableDictionary dictionary] ;
		[menuDic_1 setObject:@"0" forKey:@"level"] ;
		[menuDic_1 setObject:[nameArray objectAtIndex:i] forKey:@"name"] ;
		[self.itemArray addObject:menuDic_1] ;
		
		if (![self.openItemArray count]) {
			//如果没有打开项
			continue ;
		}
		//判断打开的菜单
		for (int j = 0 ; j < [self.openItemArray count]; j++) {
			if ([[[self.openItemArray objectAtIndex:j] objectForKey:@"name"] isEqualToString:[nameArray objectAtIndex:i]]) {
			
				//二级菜单
				NSDictionary *twoDic = [dic objectForKey:[nameArray objectAtIndex:i]] ;
				NSArray * twoArray = [twoDic allKeys]  ;
				for (int k = 0 ; k < [twoArray count] ; k++) {
					NSMutableDictionary * menuDic_2 = [NSMutableDictionary dictionary] ;
					[menuDic_2 setObject:@"2" forKey:@"level"] ;
					[menuDic_2 setObject:[twoArray objectAtIndex:k] forKey:@"name"] ;
					
					[self.itemArray addObject:menuDic_2] ;
				}
			}
		}
	}
}
/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

/*
 // Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
 */


#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.itemArray count];
}

- (NSInteger)tableView:(UITableView *)tableView 
indentationLevelForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return [[[self.itemArray objectAtIndex:[indexPath row]] objectForKey:@"level"] intValue];	
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
	NSDictionary *dic = [self.itemArray objectAtIndex:[indexPath row]] ;
	
	if(![[dic objectForKey:@"level"] intValue])
	{
		//如果为0则为主菜单
		cell.selectionStyle = UITableViewCellSelectionStyleNone ;
	}// Configure the cell.
	else {
		cell.selectionStyle = UITableViewCellSelectionStyleBlue ;
	}

	cell.text = [dic objectForKey:@"name"];
	
	
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
	NSDictionary *dic = [self.itemArray objectAtIndex:[indexPath row]] ;
	
	if(![[dic objectForKey:@"level"] intValue])
	{
		//如果为0则为主菜单
		for (int i = 0 ; i < [self.openItemArray count]; i++) {
			if ([[[self.openItemArray objectAtIndex:i] objectForKey:@"name"] isEqualToString:[dic objectForKey:@"name"]]) {
				[self.openItemArray removeObjectAtIndex:i] ;
				[self readPlistToArray] ;
				[self.tableView reloadData] ;
				
				return ;
			}
		}
		
		//
		[self.openItemArray addObject:dic] ;
		[self readPlistToArray] ;
		[self.tableView reloadData] ;
	}
	else {
		//如果是菜单项处理相关操作
	}
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
	[self.itemArray release] ;
	[self.openItemArray release] ;
    [super dealloc];
}


@end

