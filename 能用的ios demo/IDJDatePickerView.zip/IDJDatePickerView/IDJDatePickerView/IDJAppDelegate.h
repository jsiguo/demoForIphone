//
//  IDJAppDelegate.h
//  IDJDatePickerView
//
//  Created by lihaifeng on 11-12-1.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IDJViewController;

@interface IDJAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) IDJViewController *viewController;

@end
