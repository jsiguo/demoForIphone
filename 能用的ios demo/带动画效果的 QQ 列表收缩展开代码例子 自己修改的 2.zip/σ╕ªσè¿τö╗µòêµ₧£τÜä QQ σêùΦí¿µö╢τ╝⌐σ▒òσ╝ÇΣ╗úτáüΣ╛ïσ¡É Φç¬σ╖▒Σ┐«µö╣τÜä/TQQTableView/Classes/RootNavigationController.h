//
//  RootNavigationController.h
//  RootViewController.h
//  TQQTableView
//
//  Created by Futao on 11-6-21.
//  Copyright 2011 ftkey.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootNavigationController : UINavigationController {

}

@end

#import "QQSectionHeaderView.h"

@interface RootViewController : UITableViewController<QQSectionHeaderViewDelegate> {
	
	NSMutableArray *lists;
	NSMutableArray * openItemArray ;
	
}

@end

