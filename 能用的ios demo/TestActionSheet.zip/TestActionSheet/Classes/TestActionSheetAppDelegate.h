//
//  TestActionSheetAppDelegate.h
//  TestActionSheet
//
//  Created by Cui Lionel on 10-12-8.
//  Copyright 2010 vlion. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TestActionSheetViewController;

@interface TestActionSheetAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    TestActionSheetViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet TestActionSheetViewController *viewController;

@end

