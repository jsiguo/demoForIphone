//
//  AppDelegate.h
//  TQQTableView
//
//  Created by Futao on 11-6-21.
//  Copyright 2011 ftkey.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RootNavigationController;
@interface AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	RootNavigationController *rootNav;

}

@property (nonatomic, retain)  UIWindow *window;
@property (nonatomic, retain)  RootNavigationController *rootNav;

@end

